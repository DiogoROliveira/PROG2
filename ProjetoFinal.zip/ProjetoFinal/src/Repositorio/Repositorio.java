package Repositorio;
import Entidades.*;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Repositorio implements Serializable {

    private Map<String, ArrayList<Cliente>> clientes = new HashMap<>();
    private Map<String, PrestadorServico> prestadores = new HashMap<>();
    private Map<PrestadorServico, Map<String, LocalEntregaRecolha>> locaisPorPrestador = new HashMap<>();

    private static Repositorio repo;


    public Repositorio(){}

    public static Repositorio getInstance(){
        if (repo == null){
            repo = new Repositorio();
        }
        return repo;
    }

    public Map<String, ArrayList<Cliente>> getClientes(){return clientes;}

    public Map<String, PrestadorServico> getPrestadores() {
        return prestadores;
    }

    public Map<PrestadorServico, Map<String, LocalEntregaRecolha>> getLocaisPorPrestador() {
        return locaisPorPrestador;
    }

    public void writeFile() {
        File file = new File("src/Files/data.repo");
        try {
            FileOutputStream fileOut = new FileOutputStream(file);
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
            objOut.writeObject(this);
            objOut.close();
            fileOut.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
        }
    }

    public static void readFile(){
        try{
            File file = new File("src/Files/data.repo");
            if(file.exists()){
                FileInputStream fileIn = new FileInputStream(file);
                ObjectInputStream objIn = new ObjectInputStream(fileIn);
                repo = (Repositorio) objIn.readObject();
                objIn.close();
                fileIn.close();
            }
        }
        catch(ClassNotFoundException | IOException e) {
            JOptionPane.showMessageDialog(null,"Erro: "+e.getMessage());
        }
    }

}
