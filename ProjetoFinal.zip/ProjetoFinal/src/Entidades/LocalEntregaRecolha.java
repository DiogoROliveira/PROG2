package Entidades;

import java.util.List;

public class LocalEntregaRecolha {
    private String morada;
    private String localidade;
    private int telefone;
    private String tipoServico;
    private List<Funcionario> funcionarios;
}
