package Entidades;

public enum EstadoMarcacao {
    CONFIRMADA,
    CANCELADA,
    NAOPAGA,
    PAGA
}
