package Entidades;

import java.io.Serializable;

public class Funcionario extends User implements Serializable{



}
