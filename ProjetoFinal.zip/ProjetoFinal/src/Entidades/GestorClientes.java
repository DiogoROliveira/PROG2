package Entidades;

import java.util.ArrayList;
import java.util.Iterator;

public class GestorClientes extends Cliente {

    private static final GestorClientes instance = new GestorClientes();
    public GestorClientes(){}

    public static synchronized GestorClientes getInstance() {
        return instance;
    }

    public void addCliente(Cliente cliente) {
        String localidade = cliente.getLocalidade();

        /*
        // se ainda n existe uma lista para a localidade
        // adiciona uma nova lista
        if (!clientes.containsKey(localidade))
            clientes.put(localidade, new ArrayList<>());
        // adiciona o cliente a lista
        clientes.get(localidade).add(c);
        */

        try{
            rep.getClientes().get(localidade).add(cliente);
        }
        catch (NullPointerException e){
            rep.getClientes().put(localidade, new ArrayList<>());
            rep.getClientes().get(localidade).add(cliente);
        }

    }

    public Iterator<Cliente> getClienteByLocalidade(String localidade){
        return rep.getClientes().get(localidade).iterator();
    }





}