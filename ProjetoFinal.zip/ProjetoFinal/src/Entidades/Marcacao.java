package Entidades;

import java.io.Serializable;

public class Marcacao implements Serializable {
    private int idAppointment;
    private Cliente client;
    private String appointmentDate;
    private String employee;
    private String clinicName;
    private float appointmentTotal;
    private EstadoMarcacao state;
    private String service;
    private String type;

    public Marcacao(){}

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public float getAppointmentTotal() {
        return appointmentTotal;
    }

    public void setAppointmentTotal(float appointmentTotal) {
        this.appointmentTotal = appointmentTotal;
    }

    public int getIdAppointment() {
        return idAppointment;
    }

    public void setIdAppointment(int idAppointment) {
        this.idAppointment = idAppointment;
    }

    public Cliente getClient() {
        return client;
    }

    public void setClient(Cliente client) {
        this.client = client;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getEmployee() {
        return employee;
    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public EstadoMarcacao getState() {
        return state;
    }

    public void setState(EstadoMarcacao state) {
        this.state = state;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
