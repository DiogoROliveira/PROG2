package Entidades;

import java.util.List;

public class PrestadorServico extends User{

    private String nome;
    private String morada;
    private int telefone;
    private List<Location> locadidades;



    public PrestadorServico(){
    }



}
