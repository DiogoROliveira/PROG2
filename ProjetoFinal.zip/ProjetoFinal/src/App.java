import Entidades.*;
import Repositorio.*;

import java.util.Iterator;

public class App {
    public static void main(String[] args){

        Repositorio rep;
        Repositorio.readFile();
        rep = Repositorio.getInstance();

        if(rep.getClientes().isEmpty()){
            System.out.println("Teste");
        }

        try{
            Iterator <Cliente> itr = GestorClientes.getInstance().getClienteByLocalidade("Viana");
            while (itr.hasNext()){
                System.out.println(itr.next().toString());
            }
        }
        catch (NullPointerException e){
            System.out.println("Localidade inexistente");
        }


        try {
            rep.writeFile();
            System.out.println("Sucesso");
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
