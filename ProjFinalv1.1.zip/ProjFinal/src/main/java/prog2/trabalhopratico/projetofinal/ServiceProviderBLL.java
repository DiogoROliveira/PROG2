package prog2.trabalhopratico.projetofinal;


import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;
import prog2.trabalhopratico.projetofinal.Exceptions.RemoveException;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServiceProviderBLL {
    private Map<String, ServiceProvider> serviceProviderMap;
    private static ServiceProviderBLL instance = null;

    public static ServiceProviderBLL getInstance() {
        if(instance == null){
            instance = new ServiceProviderBLL();
        }
        return instance;
    }

    private ServiceProviderBLL(){
        serviceProviderMap = new HashMap<>();
    }

    public Map<String, ServiceProvider> getServiceProviderMap() {
        return serviceProviderMap;
    }

    public void setServiceProviderMap(Map<String, ServiceProvider> serviceProviderMap) {
        this.serviceProviderMap = serviceProviderMap;
    }

    public void createServiceProvider(ServiceProvider serviceProvider) throws UserAlreadyExistsException {
        if(serviceProviderMap.containsKey(serviceProvider.getUsername())){
            throw new UserAlreadyExistsException("Prestador de Serviços ja existe!");
        }
        try {
            serviceProviderMap.put(serviceProvider.getUsername(), serviceProvider);
            System.out.println("Prestador de serviço criado com sucesso!");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void removeLocation(Location location, List<Location> locations) throws RemoveException {
        boolean found = false;
        for(Location l : locations){
            if(l.equals(location)){
                found = true;
                break;
            }
        }
        if(!found){
            throw new RemoveException("Local de entrega/recolha não encontrado!");
        }
        else locations.remove(location);
    }
}
