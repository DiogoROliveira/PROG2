package prog2.trabalhopratico.projetofinal;

public class Service {
    private String type;
    private float price;
}