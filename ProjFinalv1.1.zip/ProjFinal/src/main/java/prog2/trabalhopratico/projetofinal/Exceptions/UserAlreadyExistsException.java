package prog2.trabalhopratico.projetofinal.Exceptions;

public class UserAlreadyExistsException extends Exception{
    public UserAlreadyExistsException(String message){super(message);}
}
