package prog2.trabalhopratico.projetofinal;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ServiceProvider extends User implements Serializable {

    private List<Location> localER;
    @Serial
    private static final long serialVersionUID = 1L;

    public ServiceProvider(){}

    public ServiceProvider(String username, String passwd, String nome, int numCC, int NIF, String telefone, String morada, String localidade){
        super(username, passwd,nome, numCC, NIF, telefone, morada, localidade);
        localER = new ArrayList<>();
    }

    public List<Location> getLocalER() {
        return localER;
    }

    public void setLocalER(List<Location> localER) {
        this.localER = localER;
    }


    public void listLocations(){
        for(Location l : localER){
            System.out.println("Nome: " + l.getName());
            System.out.println("Morada: " + l.getAddress());
            System.out.println("NIF: " + l.getNIF());
            System.out.println("Telefone: " + l.getPhoneNumber());
        }
    }





}



