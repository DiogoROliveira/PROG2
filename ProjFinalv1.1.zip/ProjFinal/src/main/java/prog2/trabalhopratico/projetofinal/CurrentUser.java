package prog2.trabalhopratico.projetofinal;



public class CurrentUser {
    public static Client client;
    public static ServiceProvider serviceProvider;
    public static Admin admin;
    public static Employee employee;
}
