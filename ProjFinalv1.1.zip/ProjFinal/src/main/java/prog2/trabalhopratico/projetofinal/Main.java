package prog2.trabalhopratico.projetofinal;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import prog2.trabalhopratico.projetofinal.Exceptions.*;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 300, 400);
        stage.setMinHeight(400);
        stage.setMinWidth(300);
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {

        Repository repo;
        repo = Repository.getInstance();

        try {
            ClientBLL.getInstance().addClient(new Client("a", "a", "Joao", 124, 523,"4352", "rua", "Viana"));
        }
        catch (UserAlreadyExistsException | ClientException e){
            System.out.println("Erro: " + e.getMessage());
        }

        Client c = ClientBLL.getInstance().getClients().get("a");

        try {
            AppointmentBLL.getInstance().registerAppointment(new Appointment(1,c, new Date(123, Calendar.DECEMBER,6), "Maria", "Veterinaria Minho",  19.70,AppointmentState.CONFIRMADA, "Consulta", "Veterinaria"), c);
        }
        catch (AppointmentException e){
            System.out.println(e.getMessage());
        }

        Appointment a = AppointmentBLL.getInstance().getAppointments().get(1);
        System.out.println(ClientBLL.getInstance().getClients());

        try {
            ClientBLL.getInstance().changeAppointmentDate(a, new Date(124, Calendar.JANUARY, 10));
        }catch (DateAlreadyTakenException e){
            System.out.println(e.getMessage());
        }

        try {
            ClientBLL.getInstance().payAppointment(a);
        }catch (AppointmentAlreadyPaidException e){
            System.out.println(e.getMessage());
        }

        c.listAppointments();
        launch();
        try {
            repo.writeFile("src\\main\\resources\\Files\\repo.dat");
            System.out.println("Ficheiro serializado com sucesso");
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}