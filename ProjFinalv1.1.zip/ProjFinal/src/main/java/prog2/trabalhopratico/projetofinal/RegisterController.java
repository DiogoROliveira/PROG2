package prog2.trabalhopratico.projetofinal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;

import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {

    private boolean passwordValid = false;
    private boolean fieldsValid = false;
    @FXML
    private ChoiceBox<String> accountTypeCF;

    @FXML
    private TextField moradaField;

    @FXML
    private TextField nifField;

    @FXML
    private TextField nomeField;

    @FXML
    private TextField numCCField;

    @FXML
    private PasswordField password1Field;

    @FXML
    private PasswordField password2Field;

    @FXML
    private Button registerButton;

    @FXML
    private TextField telefoneField;

    @FXML
    private TextField usernameField;

    @FXML
    private Text passwordError;


    public void initialize(URL url, ResourceBundle rb) {
        accountTypeCF.getItems().addAll("Cliente", "Funcionário", "Prestador de Serviço");
    }

    @FXML
    void back(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("login.fxml")));
            Scene scene = new Scene (root);
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    void register(ActionEvent event) {

        if(!passwordValid){
            alert("Password inválida!");
            clear();
            return;
        }

        if(accountTypeCF.getValue().equals("Cliente")){
            Client client = new Client();
            setData(client);
            try {
                ClientBLL.getInstance().addClient(client);
            }catch (UserAlreadyExistsException e){
                System.out.println(e.getMessage());
                alert("Username ja está em uso, por favor tente com outro!");
                clear();
            }
        }else if(accountTypeCF.getValue().equals("Funcionário")){
            Employee employee = new Employee();
            setData(employee);
            try {
                EmployeeBLL.getInstance().addEmployee(employee);
            }catch (UserAlreadyExistsException e){
                System.out.println(e.getMessage());
                alert("Username ja está em uso, por favor tente com outro!");
                clear();
            }
        } else if (accountTypeCF.getValue().equals("Prestador de Serviço")) {
            ServiceProvider serviceProvider = new ServiceProvider();
            setData(serviceProvider);
            try {
                ServiceProviderBLL.getInstance().createServiceProvider(serviceProvider);
            }catch (UserAlreadyExistsException e){
                System.out.println(e.getMessage());
                alert("Username ja está em uso, por favor tente com outro!");
                clear();
            }
        }
    }


    private void setData(User u){
        u.setNome(nomeField.getText());
        u.setUsername(usernameField.getText());
        u.setPasswd(password1Field.getText());
        u.setMorada(moradaField.getText());
        u.setTelefone(telefoneField.getText());
        u.setNumCC(Integer.parseInt(numCCField.getText()));
        u.setNIF(Integer.parseInt(nifField.getText()));
    }


    private void alert(String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro de registo!");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    private void clear(){
        nomeField.clear();
        moradaField.clear();
        telefoneField.clear();
        numCCField.clear();
        nifField.clear();
        password1Field.clear();
        password2Field.clear();
        usernameField.clear();
        accountTypeCF.setValue(null);
    }

    private void verifyPassword(KeyEvent keyEvent) {
        String password = password1Field.getText();
        if(!password.equals(password2Field.getText())){
            passwordError.setVisible(true);
            passwordValid = false;
        }
        else {
            passwordValid = true;
            passwordError.setVisible(false);
        }
    }

    private void verifyFields(){

    }

}
