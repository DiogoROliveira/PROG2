package prog2.trabalhopratico.projetofinal;

public enum AppointmentState {
    CONFIRMADA,
    CANCELADA,
    NAOPAGA,
    PAGA
}