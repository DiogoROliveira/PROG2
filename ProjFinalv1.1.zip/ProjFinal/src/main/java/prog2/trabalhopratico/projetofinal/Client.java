package prog2.trabalhopratico.projetofinal;

import prog2.trabalhopratico.projetofinal.Exceptions.ClientException;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Client extends User implements Serializable{

    @Serial
    private static final long serialVersionUID = 1L;
    private List<Appointment> appointments = new ArrayList<>();

    public Client(){}
    public Client(String username, String passwd, String nome, int numCC, int NIF, String telefone, String morada, String localidade)
            throws ClientException {

        super(username, passwd, nome, numCC, NIF, telefone, morada, localidade);

        if (!(Validator.validaString(username) &&
                Validator.validaString(passwd) &&
                Validator.validaInt(numCC) &&
                Validator.validaInt(NIF) &&
                Validator.validaString(nome) &&
                Validator.validaString(morada) &&
                Validator.validaString(localidade) &&
                Validator.validaString(telefone))) {
            throw new ClientException("Todos os campos são obrigatórios");
        }
    }

    public List<Appointment> getAppointments(){return appointments;}

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }
    public void listAppointments(){
        int nAppointment = 1;
        for(Appointment a : appointments){
            System.out.println("\n----------------------------------------");
            System.out.println("Nº Consulta: " + nAppointment++);
            System.out.println("Clinica: " + a.getClinicName());
            System.out.println("Data:" + a.getAppointmentDate());
            System.out.println("Serviços: " + a.getService());
            System.out.println("Estado: " + a.getState());
            System.out.println("Valor: " + a.getAppointmentTotal());
            System.out.println("Funcionario: " + a.getEmployee());
            System.out.println("Cliente: " + a.getClient().getNome());
            System.out.println("\n----------------------------------------");
        }
    }



}

