package prog2.trabalhopratico.projetofinal;

import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;

import java.util.HashMap;
import java.util.Map;

public class EmployeeBLL {

    private Map<String, Employee> employeeMap;
    private static EmployeeBLL instance = null;

    private EmployeeBLL(){
        employeeMap = new HashMap<>();
    }

    public static EmployeeBLL getInstance(){
        if(instance == null){
            instance = new EmployeeBLL();
        }
        return instance;
    }

    public void addEmployee(Employee employee) throws UserAlreadyExistsException {
        if(employeeMap.containsKey(employee.getUsername())){
            throw new UserAlreadyExistsException("Funcionário já existe!");
        }
        try {
            employeeMap.put(employee.getUsername(), employee);
            System.out.println("Funcionário criado com sucesso!");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public Map<String, Employee> getEmployeeMap() {
        return employeeMap;
    }

    public void setEmployeeMap(Map<String, Employee> employeeMap) {
        this.employeeMap = employeeMap;
    }
}
