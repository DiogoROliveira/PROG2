package Entidades;

public class Service {
    private String type;
    private float price;
}
