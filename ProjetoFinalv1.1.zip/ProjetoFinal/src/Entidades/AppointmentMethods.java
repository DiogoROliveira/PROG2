package Entidades;

public class AppointmentMethods {

    public void createAppointment(){}
}
