package Entidades;

import Exceptions.ClienteException;
import MetodosAbstratos.Validator;

import java.io.Serial;
import java.util.ArrayList;
import java.util.List;

public class Client extends User {
    @Serial
    private static final long serialVersionUID = 1L;
    private String localidade;
    private List<Appointment> appointments;

    public Client() {
        this.appointments = new ArrayList<>();
    }

    public List<Appointment> getAppointments(){return appointments;}

    public Client(String username, String passwd, String nome, int numCC, int NIF, int telefone, String morada, String localidade)
            throws ClienteException {

        super(username, passwd, nome, numCC, NIF, telefone, morada);

        if (!(Validator.validaString(username) &&
                Validator.validaString(passwd) &&
                Validator.validaInt(numCC) &&
                Validator.validaInt(NIF) &&
                Validator.validaString(nome) &&
                Validator.validaString(morada) &&
                Validator.validaString(localidade) &&
                Validator.validaInt(telefone))) {
            throw new ClienteException("Todos os campos são obrigatórios");
        }

        this.localidade = localidade;
    }

    public String getLocalidade() {
        return localidade;
    }

    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "localidade='" + localidade + "'," +
                super.toString() + "}";
    }




}
