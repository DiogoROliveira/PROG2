package Entidades;

public enum AppointmentState {
    CONFIRMADA,
    CANCELADA,
    CONCLUIDA
}
