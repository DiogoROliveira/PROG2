package Entidades;

import Repositorio.Repository;

import java.io.Serializable;

public class User implements Serializable {

    protected Repository rep = Repository.getInstance();
    private String passwd;
    private String username;
    private String nome;
    private int numCC;
    private int NIF;
    private int telefone;
    private String morada;


    public  User(){}

    public User(String username, String passwd, String nome, int numCC, int NIF, int telefone, String morada) {
        this.username = username;
        this.passwd = passwd;
        this.nome = nome;
        this.numCC = numCC;
        this.NIF = NIF;
        this.telefone = telefone;
        this.morada = morada;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumCC() {
        return numCC;
    }

    public void setNumCC(int numCC) {
        this.numCC = numCC;
    }

    public int getNIF() {
        return NIF;
    }

    public void setNIF(int NIF) {
        this.NIF = NIF;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    @Override
    public String toString() {
        return " " +
                "passwd='" + passwd + '\'' +
                ", username='" + username + '\'' +
                ", nome='" + nome + '\'' +
                ", numCC=" + numCC +
                ", NIF=" + NIF +
                ", telefone=" + telefone +
                ", morada='" + morada + '\''
                ;
    }
}
