package Entidades;

public class ServiceProvider extends User{

    private String nome;
    private String morada;
    private int telefone;
    // private List<LocalEntregaRecolha> locadidades;



    public ServiceProvider(){
    }



}
