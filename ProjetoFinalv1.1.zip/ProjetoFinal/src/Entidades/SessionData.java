package Entidades;

public class SessionData {
    public static Client client;
    public static ServiceProvider serviceProvider;
    public static Employee employee;
}
