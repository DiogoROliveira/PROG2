package Entidades;

import java.io.Serializable;

public class Appointment implements Serializable {
    private int idAppointment;
    private Client client;
    private String appointmentDate;
    private String employee;
    private String clinicName;
    private float appointmentTotal;
    private AppointmentState state;
    private PaymentSate pState;
    private String service;
    private String type;

    public Appointment(){}

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public float getAppointmentTotal() {
        return appointmentTotal;
    }

    public void setAppointmentTotal(float appointmentTotal) {
        this.appointmentTotal = appointmentTotal;
    }

    public int getIdAppointment() {
        return idAppointment;
    }

    public void setIdAppointment(int idAppointment) {
        this.idAppointment = idAppointment;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getEmployee() {
        return employee;
    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public AppointmentState getState() {
        return state;
    }

    public void setState(AppointmentState state) {
        this.state = state;
    }

    public PaymentSate getpState() {
        return pState;
    }

    public void setpState(PaymentSate pState) {
        this.pState = pState;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
