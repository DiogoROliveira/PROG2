package Entidades;

public enum PaymentSate {
    NAOPAGA,
    PAGA
}
