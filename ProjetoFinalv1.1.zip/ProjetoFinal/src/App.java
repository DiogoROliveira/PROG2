import Entidades.*;
import GUI.*;
import Repositorio.*;

import javax.swing.*;
import java.awt.*;
import java.util.Iterator;

public class App {
    public static void main(String[] args){

        Repository rep;
        Repository.readFile("src\\Files\\data.repo");
        rep = Repository.getInstance();

        if(rep.getClientes().isEmpty()){
            System.out.println("Teste");
        }

        try {
            Client c1 = new Client("a", "a", "Joao", 124, 523,4352, "rua", "Viana");
        }
        catch (Exception e){
            System.out.println("Erro: " + e.getMessage());
        }

        JFrame frame = new JFrame("PetCare");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(700, 500));
        frame.setMinimumSize(new Dimension(500, 300));
        frame.setResizable(true);
        new LoginGUI(frame);



        try {
            rep.writeFile("src\\Files\\data.repo");
            System.out.println("Sucesso");
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
