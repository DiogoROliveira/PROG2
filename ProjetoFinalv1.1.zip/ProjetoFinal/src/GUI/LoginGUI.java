package GUI;

import javax.swing.*;
import Entidades.*;
import Exceptions.UserNotFound;

import java.awt.*;
import java.util.Arrays;

public class LoginGUI extends JFrame{

    private JLabel lbUsername = new JLabel("Username");
    private JLabel lbPassword = new JLabel("Password");
    private JTextField tfUsername = new JTextField();
    private JPanel jpUserLogin = new JPanel();
    private JPasswordField tfPassword;
    private JButton btnLogin = new JButton("Login");
    private JButton btnClear = new JButton("Clear");
    private JButton btnRegister;
    private LoginControl loginC;

    public LoginGUI(JFrame frame){

        loginC = new LoginControl();
        tfPassword = new JPasswordField();

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 2, 5, 5));
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnClear);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(4, 1, 5, 5));
        formPanel.setOpaque(false);
        formPanel.add(lbUsername);
        formPanel.add(tfUsername);
        formPanel.add(lbPassword);
        formPanel.add(tfPassword);

        jpUserLogin.setLayout(new BorderLayout());
        jpUserLogin.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jpUserLogin.setBackground(new Color(255, 178, 102));
        jpUserLogin.add(buttonPanel, BorderLayout.CENTER);
        jpUserLogin.add(formPanel, BorderLayout.NORTH);
        frame.add(jpUserLogin);
        frame.setVisible(true);
        BtnClear();
        BtnLogin(frame);


    }

    public void clearTF(){
        tfUsername.setText("");
        tfPassword.setText("");
    }

    public void BtnClear(){btnClear.addActionListener(e -> clearTF());}

    public void BtnLogin(JFrame frame) {
        btnLogin.addActionListener(e -> actionBtnLogin(frame));
    }

    public void actionBtnLogin(JFrame frame){
        String user, passwd;
        user = tfUsername.getText();
        passwd = Arrays.toString(tfPassword.getPassword());
        try {
            User login = loginC.Login(user, passwd);
            if(login instanceof Client){
                jpUserLogin.setVisible(false);
            }
            if(login instanceof ServiceProvider){
                jpUserLogin.setVisible(false);
            }
            if (login instanceof Employee){
                jpUserLogin.setVisible(false);
            }
        }
        catch (UserNotFound e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }




}
