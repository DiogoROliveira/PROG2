module com.example.projfinal {
    requires javafx.controls;
    requires javafx.fxml;

    opens prog2.trabalhopratico.projetofinal to javafx.fxml;
    exports prog2.trabalhopratico.projetofinal;
    exports prog2.trabalhopratico.projetofinal.Exceptions;
    exports prog2.trabalhopratico.projetofinal.Entities;
    opens prog2.trabalhopratico.projetofinal.Entities to javafx.fxml;
    exports prog2.trabalhopratico.projetofinal.BLL;
    opens prog2.trabalhopratico.projetofinal.BLL to javafx.fxml;
}