package prog2.trabalhopratico.projetofinal.Entities;

import java.io.Serializable;

public class Employee extends User implements Serializable{

    private String type;
    private Location location;

    public Employee(){}

    public Employee(String username, String passwd, String nome, int numCC, int NIF, String  telefone, String morada, String localidade, String type, Location location) {
        super(username, passwd, nome, numCC, NIF, telefone, morada, localidade);
        this.type = type;
        this.location = location;
    }

    public String getType(){return type;}

    public void setType(String type){this.type = type;}

    public Location getLocation(){return location;}

    public void setLocation(Location location){
        this.location = location;
    }

}