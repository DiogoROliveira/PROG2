package prog2.trabalhopratico.projetofinal.BLL;

import prog2.trabalhopratico.projetofinal.Entities.Location;
import prog2.trabalhopratico.projetofinal.Entities.Service;
import prog2.trabalhopratico.projetofinal.Exceptions.ServiceException;
import prog2.trabalhopratico.projetofinal.Repository;

public class ServiceBLL {
    public static void createService(Service service, Location location) throws ServiceException {
        Repository repo = Repository.getInstance();
        service.setLocation(location);
        if(repo.getServices().containsKey(service.getID())){
            throw new ServiceException("Serviço já existe");
        }

        repo.getServices().put(service.getID(), service);
        repo.getCompanies().get(location.getAddress()).getServices().put(service.getPrice(), service);
        repo.writeFile("src\\main\\resources\\Files\\repo.dat");
    }
}
