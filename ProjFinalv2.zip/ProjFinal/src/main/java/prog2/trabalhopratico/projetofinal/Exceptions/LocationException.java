package prog2.trabalhopratico.projetofinal.Exceptions;

public class LocationException extends Exception{
    public LocationException(String message){super(message);}
}
