package prog2.trabalhopratico.projetofinal.Exceptions;

public class DateAlreadyTakenException extends Exception{
    public DateAlreadyTakenException(String message){super(message);}
}
