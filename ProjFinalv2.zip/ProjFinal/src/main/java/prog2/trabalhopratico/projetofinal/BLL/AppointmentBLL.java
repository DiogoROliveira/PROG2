package prog2.trabalhopratico.projetofinal.BLL;

import prog2.trabalhopratico.projetofinal.Entities.Client;
import prog2.trabalhopratico.projetofinal.Entities.Appointment;
import prog2.trabalhopratico.projetofinal.Exceptions.AppointmentException;
import prog2.trabalhopratico.projetofinal.Repository;

public class AppointmentBLL {
    public static void registerAppointment(Appointment appointment, Client client) throws AppointmentException {
        Repository repo = Repository.getInstance();
        if(repo.getAppointments().containsKey(appointment.getIdAppointment()))
            throw new AppointmentException("Código de consulta já existe");

        repo.getAppointments().put(appointment.getIdAppointment(), appointment);
        repo.getClients().get(client.getUsername()).getAppointments().add(appointment);
        repo.writeFile("src\\main\\resources\\Files\\repo.dat");

    }
}



