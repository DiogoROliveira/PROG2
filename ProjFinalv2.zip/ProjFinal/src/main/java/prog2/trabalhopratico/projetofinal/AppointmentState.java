package prog2.trabalhopratico.projetofinal;

public enum AppointmentState {
    PENDENTE,
    CONFIRMADA,
    CANCELADA,
    NAOPAGA,
    PAGA
}