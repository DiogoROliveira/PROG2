package prog2.trabalhopratico.projetofinal.BLL;

import prog2.trabalhopratico.projetofinal.Entities.Admin;
import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;
import prog2.trabalhopratico.projetofinal.Repository;


public class AdminBLL {

    public static void addAdmin(Admin admin) throws UserAlreadyExistsException {
        Repository repo = Repository.getInstance();
        if(repo.getAdmins().containsKey(admin.getUsername())){
            throw new UserAlreadyExistsException("Admin já existe!");
        }
        repo.getAdmins().put(admin.getUsername(), admin);
        repo.writeFile("src\\main\\resources\\Files\\repo.dat");
    }
}
