package prog2.trabalhopratico.projetofinal.Entities;

import prog2.trabalhopratico.projetofinal.Entities.Location;

import java.io.Serializable;

public class Service implements Serializable {
    private String name;
    private int ID;
    private double price;
    private Location location;

    public Service(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
}