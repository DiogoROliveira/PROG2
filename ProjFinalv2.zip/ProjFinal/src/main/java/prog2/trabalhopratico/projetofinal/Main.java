package prog2.trabalhopratico.projetofinal;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import prog2.trabalhopratico.projetofinal.BLL.AdminBLL;
import prog2.trabalhopratico.projetofinal.BLL.ClientBLL;
import prog2.trabalhopratico.projetofinal.BLL.LocationBLL;
import prog2.trabalhopratico.projetofinal.BLL.ServiceProviderBLL;
import prog2.trabalhopratico.projetofinal.Entities.Admin;
import prog2.trabalhopratico.projetofinal.Entities.Client;
import prog2.trabalhopratico.projetofinal.Entities.Location;
import prog2.trabalhopratico.projetofinal.Entities.ServiceProvider;
import prog2.trabalhopratico.projetofinal.Exceptions.*;

import java.io.IOException;


public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 500);
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {

        Repository repo;
        try {
            Repository.readFile("src\\main\\resources\\Files\\repo.dat");
        }catch (ClassNotFoundException | IOException e){
            System.out.println(e.getMessage());
        }
        repo = Repository.getInstance();
        if(repo.getAdmins().isEmpty()){
            System.out.println("teste");
            Admin a1 = new Admin();
            a1.setUsername("admin");
            a1.setPasswd("admin");
            a1.setMorada("morada1");
            a1.setNome("Administrador");
            a1.setNIF(12345);
            a1.setNumCC(12345);
            a1.setTelefone("12345");
            try {
                AdminBLL.addAdmin(a1);
            }catch (UserAlreadyExistsException e){
                System.out.println(e.getMessage());
            }
        }
        if(repo.getClients().isEmpty()){
            System.out.println("teste");
            Client c1 = new Client();
            c1.setUsername("cliente");
            c1.setPasswd("cliente");
            c1.setMorada("morada2");
            c1.setNome("Cliente");
            c1.setNIF(54321);
            c1.setNumCC(54321);
            c1.setTelefone("43535");
            try {
                ClientBLL.addClient(c1);
            }catch (UserAlreadyExistsException e){
                System.out.println(e.getMessage());
            }
        }

        if(repo.getServiceProviders().isEmpty()){
            ServiceProvider s1 = new ServiceProvider();
            s1.setUsername("prestadorservico");
            s1.setPasswd("prestadorservico");
            s1.setMorada("morada3");
            s1.setNome("Prestador de Serviço");
            s1.setNIF(4523);
            s1.setNumCC(535643);
            s1.setTelefone("2345436");
            try {
                ServiceProviderBLL.addServiceProvider(s1);

            }catch (UserAlreadyExistsException e){
                System.out.println(e.getMessage());
            }
        }


        if(repo.getCompanies().isEmpty()){
            Location l1 = new Location();
            ServiceProvider s1 = repo.getServiceProviders().get("prestadorservico");
            l1.setName("VetMinho");
            l1.setAddress("Rua de cima");

            try {
                LocationBLL.createLocation(l1, s1);
            }catch (LocationException e){
                System.out.println(e.getMessage());
            }
        }



        launch();
    }
}