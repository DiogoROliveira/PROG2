package prog2.trabalhopratico.projetofinal.BLL;

import prog2.trabalhopratico.projetofinal.Entities.Employee;
import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;
import prog2.trabalhopratico.projetofinal.Entities.Location;
import prog2.trabalhopratico.projetofinal.Repository;

public class EmployeeBLL {
    public static void addEmployee(Employee employee, Location location) throws UserAlreadyExistsException {
        Repository repo = Repository.getInstance();
        if(repo.getEmployees().containsKey(employee.getUsername())){
            throw new UserAlreadyExistsException("Funcionário já existe!");
        }
        repo.getEmployees().put(employee.getUsername(), employee);
        repo.getCompanies().get(location.getAddress()).getEmployees().add(employee);
        Repository.getInstance().writeFile("src\\main\\resources\\Files\\repo.dat");
    }
}
