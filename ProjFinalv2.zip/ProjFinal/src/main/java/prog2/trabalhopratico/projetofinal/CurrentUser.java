package prog2.trabalhopratico.projetofinal;


import prog2.trabalhopratico.projetofinal.Entities.Admin;
import prog2.trabalhopratico.projetofinal.Entities.Client;
import prog2.trabalhopratico.projetofinal.Entities.Employee;
import prog2.trabalhopratico.projetofinal.Entities.ServiceProvider;

public class CurrentUser {
    public static Client client;
    public static ServiceProvider serviceProvider;
    public static Admin admin;
    public static Employee employee;
}
