package prog2.trabalhopratico.projetofinal.Entities;

import prog2.trabalhopratico.projetofinal.AppointmentState;

import java.io.Serializable;
import java.util.Date;

public class Appointment implements Serializable {
    private int idAppointment;
    private Client client;
    private Date appointmentDate;
    private String employee;
    private String clinicName;
    private double appointmentTotal;
    private AppointmentState state;
    private String service;
    private String type;

    public Appointment(){}

    public Appointment(int idAppointment, Client client, Date appointmentDate, String employee, String clinicName, double appointmentTotal, AppointmentState state, String service, String type) {
        this.idAppointment = idAppointment;
        this.client = client;
        this.appointmentDate = appointmentDate;
        this.employee = employee;
        this.clinicName = clinicName;
        this.appointmentTotal = appointmentTotal;
        this.state = state;
        this.service = service;
        this.type = type;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public double getAppointmentTotal() {
        return appointmentTotal;
    }

    public void setAppointmentTotal(double appointmentTotal) {
        this.appointmentTotal = appointmentTotal;
    }

    public int getIdAppointment() {
        return idAppointment;
    }

    public void setIdAppointment(int idAppointment) {
        this.idAppointment = idAppointment;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getEmployee() {
        return employee;
    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public AppointmentState getState() {
        return state;
    }

    public void setState(AppointmentState state) {
        this.state = state;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
