package prog2.trabalhopratico.projetofinal.Exceptions;

public class AppointmentException extends Exception{
    public AppointmentException(String message){super(message);}
}
