package prog2.trabalhopratico.projetofinal.Exceptions;

public class ServiceException extends Exception{
    public ServiceException(String message){super(message);}
}
