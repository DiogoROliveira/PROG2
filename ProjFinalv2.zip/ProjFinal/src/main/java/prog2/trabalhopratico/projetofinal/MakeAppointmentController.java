package prog2.trabalhopratico.projetofinal;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import prog2.trabalhopratico.projetofinal.Entities.*;


import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class MakeAppointmentController implements Initializable {
    @FXML
    public DatePicker datePicker;
    @FXML
    public ChoiceBox<String> serviceCB;
    @FXML
    public Label pickedLocation;
    @FXML
    public Label specialtyLabel;
    @FXML
    public Label finalPriceLabel;


    public void back(MouseEvent event) {
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("listLocations.fxml")));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Locais de entrega/recolha");
            stage.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Repository repo = Repository.getInstance();
        Client c1 = new Client();
        c1.setNome(CurrentUser.client.getNome());
        pickedLocation.setText(ListLocationsController.currentLocation);

        for (Location l : repo.getCompanies().values()) {
            if (l.getName().equals(ListLocationsController.currentLocation));

        }
        serviceCB.getItems().add("Teste");
        for (Service s1 : Repository.getInstance().getServices().values()) {
            if (pickedLocation.getText().equalsIgnoreCase(s1.getLocation().getName()))
                serviceCB.getItems().addAll(s1.getName());
        }
    }
}