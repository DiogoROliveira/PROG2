package prog2.trabalhopratico.projetofinal.BLL;



import prog2.trabalhopratico.projetofinal.Entities.Client;
import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;
import prog2.trabalhopratico.projetofinal.Repository;

public class ClientBLL{
    public static void addClient(Client client) throws UserAlreadyExistsException {
        String userName = client.getUsername();
        Repository repo = Repository.getInstance();
        if(repo.getClients().containsKey(userName)) {
            throw new UserAlreadyExistsException("Cliente ja existe!");
        }
        repo.getClients().put(userName, client);
        repo.writeFile("src\\main\\resources\\Files\\repo.dat");
    }
}

