package prog2.trabalhopratico.projetofinal.Exceptions;

public class ClientException extends Exception{
    public ClientException(String message){super(message);}
}
