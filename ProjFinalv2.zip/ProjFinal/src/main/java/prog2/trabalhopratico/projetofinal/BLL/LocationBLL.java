package prog2.trabalhopratico.projetofinal.BLL;

import prog2.trabalhopratico.projetofinal.Entities.Location;
import prog2.trabalhopratico.projetofinal.Exceptions.LocationException;
import prog2.trabalhopratico.projetofinal.Repository;
import prog2.trabalhopratico.projetofinal.Entities.ServiceProvider;

import java.util.*;

public class LocationBLL {
    public static void createLocation(Location location, ServiceProvider serviceProvider) throws LocationException {
        Repository repo = Repository.getInstance();
        location.setOwner(serviceProvider);
        if(repo.getCompanies().containsKey(location.getAddress())){
            throw new LocationException("Localidade já existe!");
        }
        if(!repo.getLocations().containsKey(serviceProvider)){
            repo.getLocations().put(serviceProvider, new ArrayList<>());
        }

        repo.getCompanies().put(location.getAddress(), location);
        repo.getLocations().get(serviceProvider).add(location);
        repo.writeFile("src\\main\\resources\\Files\\repo.dat");

    }
}

