package prog2.trabalhopratico.projetofinal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class LoginController {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;


    @FXML
    private void clearText() {
        usernameField.clear();
        passwordField.clear();
    }

    @FXML
    void login(ActionEvent event) {
        boolean found = false;
        ClientBLL clientBLL;
        clientBLL = ClientBLL.getInstance();

        try {
            for(Client c : clientBLL.getClients().values()){
                if(usernameField.getText().equals(c.getUsername()) && passwordField.getText().equals(c.getPasswd())){
                    found = true;
                    CurrentUser.client = c;
                    System.out.println("Login efetuado com sucesso!");

                }
            }



            if(!found)
                System.out.println("Utilizador nao encontrado!");
        } catch (Exception e){
            System.out.println("ERRO ao verificar dados de login, tente novamente!");
        }

    }

    @FXML
    void register(MouseEvent event) {

    }

}
