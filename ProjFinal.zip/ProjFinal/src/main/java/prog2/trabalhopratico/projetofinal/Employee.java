package prog2.trabalhopratico.projetofinal;

import java.io.Serializable;

public class Employee extends User implements Serializable{

    public Employee(String username, String passwd, String nome, int numCC, int NIF, int telefone, String morada, String localidade) {
        super(username, passwd, nome, numCC, NIF, telefone, morada, localidade);
    }
}