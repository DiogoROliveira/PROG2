package prog2.trabalhopratico.projetofinal;

import java.io.Serializable;

public class Admin extends User implements Serializable {

    private static final long serialVersionsUID = 1L;

    public Admin(String username, String passwd, String nome, int numCC, int NIF, int telefone, String morada, String localidade){
        super(username, passwd, nome, numCC, NIF, telefone, morada, localidade);
    }
}
