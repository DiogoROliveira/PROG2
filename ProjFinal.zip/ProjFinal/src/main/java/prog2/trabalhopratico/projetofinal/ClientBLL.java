package prog2.trabalhopratico.projetofinal;



import prog2.trabalhopratico.projetofinal.Exceptions.AppointmentAlreadyPaidException;
import prog2.trabalhopratico.projetofinal.Exceptions.DateAlreadyTakenException;
import prog2.trabalhopratico.projetofinal.Exceptions.UserAlreadyExistsException;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ClientBLL{

    private Map<String, Client> clientMap = new HashMap<>();
    private static ClientBLL instance;

    private ClientBLL(){
        super();
    }

    public static ClientBLL getInstance(){
        if(instance == null){
            instance = new ClientBLL();
        }
        return instance;
    }

    public Map<String, Client> getClients(){return clientMap;}

    public void addClient(Client client) throws UserAlreadyExistsException {
        String userName = client.getUsername();

        if(clientMap.containsKey(userName)) {
            throw new UserAlreadyExistsException("Cliente ja existe!");
        }
        clientMap.put(userName,client);
    }

    public Appointment selectPaymentAppointment(int idAppointment){
        for(Appointment ap : AppointmentBLL.getInstance().getAppointments().values()){
            if(ap.getIdAppointment() == idAppointment && ap.getState().equals(AppointmentState.NAOPAGA))
                return ap;
        }
        return null;
    }

    public void payAppointment(Appointment appointment) throws AppointmentAlreadyPaidException {
        for (Appointment ap : AppointmentBLL.getInstance().getAppointments().values()){
            if(ap.getState().equals(AppointmentState.PAGA)){
                throw new AppointmentAlreadyPaidException("A consulta já está paga!");
            }
            if(ap.equals(appointment)){
                ap.setState(AppointmentState.PAGA);
            }
        }
    }

    public void changeAppointmentDate(Appointment appointment, Date date) throws DateAlreadyTakenException {
        boolean found = false;
        for(Appointment ap : AppointmentBLL.getInstance().getAppointments().values()){
            if(ap.getAppointmentDate().equals(date)){
                found = true;
                break;
            }
        }
        if(!found){
            for(Appointment ap : AppointmentBLL.getInstance().getAppointments().values()){
                if(ap.equals(appointment)){
                    ap.setAppointmentDate(date);
                }
            }
        }
        else throw new DateAlreadyTakenException("Data já está ocupada, tente outra!");
    }
}

