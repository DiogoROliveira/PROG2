package prog2.trabalhopratico.projetofinal;

import prog2.trabalhopratico.projetofinal.Exceptions.AppointmentException;

import java.util.HashMap;
import java.util.Map;

public class AppointmentBLL {

    private Map<Integer, Appointment> appointmentMap = new HashMap<>();
    private static AppointmentBLL instance;

    public static AppointmentBLL getInstance(){
        if(instance == null){
            instance = new AppointmentBLL();
        }
        return instance;
    }

    public AppointmentBLL(){}

    public Map<Integer, Appointment> getAppointments(){return appointmentMap;}

    public void registerAppointment(Appointment appointment, Client client) throws AppointmentException {
        if(appointmentMap.containsKey(appointment.getIdAppointment()))
            throw new AppointmentException("Código de consulta já existe");

        this.appointmentMap.put(appointment.getIdAppointment(), appointment);
        client.getAppointments().add(appointment);

    }
}



