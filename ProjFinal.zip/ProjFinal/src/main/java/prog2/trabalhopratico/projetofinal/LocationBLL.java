package prog2.trabalhopratico.projetofinal;

import prog2.trabalhopratico.projetofinal.Exceptions.LocationException;

import java.util.*;

public class LocationBLL {

    private Map<String, Location> locationMap;
    private Map<ServiceProvider, List<Location>> locationsOfServiceProviders;
    private static LocationBLL instance = null;

    private LocationBLL(){
        locationMap = new HashMap<>();
        locationsOfServiceProviders = new HashMap<>();
    }

    public static LocationBLL getInstance(){
        if(instance == null){
            instance = new LocationBLL();
        }
        return instance;
    }

    public Map<String, Location> getLocationMap() {
        return locationMap;
    }

    public void setLocationMap(Map<String, Location> locationMap) {
        this.locationMap = locationMap;
    }

    public Map<ServiceProvider, List<Location>> getLocationsOfServiceProviders() {
        return locationsOfServiceProviders;
    }

    public void setLocationsOfServiceProviders(Map<ServiceProvider, List<Location>> locationsOfServiceProviders) {
        this.locationsOfServiceProviders = locationsOfServiceProviders;
    }

    public void createLocation(Location location, ServiceProvider serviceProvider) throws LocationException {
        for(ServiceProvider sv : locationsOfServiceProviders.keySet()){
            if(locationsOfServiceProviders.get(sv).contains(location)) {
                throw new LocationException("Local de entrega/recolha já existe!");
            }
        }

        if(!locationsOfServiceProviders.containsKey(serviceProvider)){
            locationsOfServiceProviders.put(serviceProvider,new ArrayList<>());
        }

        locationsOfServiceProviders.get(serviceProvider).add(location);
        serviceProvider.getLocalER().add(location);

        if(locationMap.containsKey(location.getAddress())){
            throw new LocationException("Local de entrega/recolha já existe!");
        }

        locationMap.put(location.getAddress(), location);

    }
}

