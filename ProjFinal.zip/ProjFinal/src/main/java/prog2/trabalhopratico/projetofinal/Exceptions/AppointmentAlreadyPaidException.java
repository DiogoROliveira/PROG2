package prog2.trabalhopratico.projetofinal.Exceptions;

public class AppointmentAlreadyPaidException extends Exception{
    public AppointmentAlreadyPaidException(String message){super(message);}
}
