package project;

public enum AppointmentState {
    CONFIRMADA,
    CANCELADA,
    NAOPAGA,
    PAGA
}
