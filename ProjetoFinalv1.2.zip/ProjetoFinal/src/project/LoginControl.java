package project;

public class LoginControl {

    public LoginControl(){
    }
    public User Login(String username, String passwd) throws UserNotFound {
        User newUser = new User();

        newUser.setUsername(username);
        newUser.setPasswd(passwd);

        for(User u : Repository.getInstance().getUsers()) {
            if(newUser.getUsername().equals(u.getUsername()) && newUser.getPasswd().equals(u.getPasswd())){
                Repository.getInstance().setCurrentUser(u);
                return u;
            }
        }
        throw new UserNotFound("Dados inválidos! Tente novamente.");
    }
}
