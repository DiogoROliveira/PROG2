package project;

import java.io.*;
import java.util.*;


public class Repository implements Serializable {

    private List<User> users;
    private Map<String, ServiceProvider> providerMap = new HashMap<>();
    private Map<ServiceProvider, Map<String, LocalEntregaRecolha>> locaisPorPrestador = new HashMap<>();
    private User currentUser;
    private static Repository repo;


    public Repository(){}

    public static Repository getInstance(){
        if (repo == null){
            repo = new Repository();
        }
        return repo;
    }

    public User getCurrentUser(){return currentUser;}

    public void setCurrentUser(User currentUser){this.currentUser = currentUser;}

    public List<User> getUsers(){return users;}

    public Map<String, ServiceProvider> getProviders() {
        return providerMap;
    }

    public Map<ServiceProvider, Map<String, LocalEntregaRecolha>> getLocaisPorPrestador() {
        return locaisPorPrestador;
    }

    public void writeFile(String filename){

        try{
            FileOutputStream fileOut = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(this);
            out.close();
            fileOut.close();
            System.out.printf("Dados guardados no ficheiro " + filename + "\n");
        } catch(IOException ex){
            System.out.println("ErrorSerialize: " + ex.getMessage());
        }
    }

    public static void readFile(String filename){

        try{
            FileInputStream fileIn = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            repo = (Repository) in.readObject();
            in.close();
            fileIn.close();
        } catch(IOException ex){
            System.out.println("ErrorDeserialize: " + ex.getMessage());
        } catch(ClassNotFoundException ex){
            System.out.println("project.Repository class not found. " + ex.getMessage());
        }

    }
}
