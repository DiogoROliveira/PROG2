package project;

public class ClienteException extends Exception{

    public  ClienteException(String message){
        super(message);
    }
}
