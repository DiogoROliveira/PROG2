package project;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

public class ServiceProvider extends User implements Serializable {

    private Map<String,ArrayList<LocalEntregaRecolha>> localER;
    @Serial
    private static final long serialVersionUID = 1L;


    public ServiceProvider(String username, String passwd, String nome, int numCC, int NIF, int telefone, String morada, String localidade, Map<String, ArrayList<LocalEntregaRecolha>> localER){
        super(username, passwd,nome, numCC, NIF, telefone, morada, localidade);
        this.localER = localER;
    }

    public Map<String, ArrayList<LocalEntregaRecolha>> getLocalER() {
        return localER;
    }

    public void setLocalER(Map<String, ArrayList<LocalEntregaRecolha>> localER) {
        this.localER = localER;
    }






}


