package project;

public class App {
    public static void main(String[] args){

        Repository rep;
        Repository.readFile("src\\Files\\data.repo");
        rep = Repository.getInstance();


        if(ClientManager.getInstance().getClients().isEmpty()){
            System.out.println("Teste");
        }

        try {
            Client c1 = new Client("a", "a", "Joao", 124, 523,4352, "rua", "Viana");
            ClientManager.getInstance().addCliente(c1);
            Appointment a1 = new Appointment();
            a1.setState(AppointmentState.CONFIRMADA);
            AppointmentManager.getInstance().createAppointment(a1, c1);
            c1.listAppointments();
        }
        catch (Exception e){
            System.out.println("Erro: " + e.getMessage());
        }





        /*JFrame frame = new JFrame("PetCare");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(new Dimension(700, 500));
        frame.setMinimumSize(new Dimension(500, 300));
        frame.setResizable(true);
        new LoginGUI(frame);
        */


        try {
            rep.writeFile("src\\Files\\data.repo");
            System.out.println("Sucesso");
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
