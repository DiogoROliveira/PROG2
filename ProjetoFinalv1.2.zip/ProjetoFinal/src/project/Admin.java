package project;

public class Admin {
}
