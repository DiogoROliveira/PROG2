package project;

import java.io.Serializable;

public class Employee extends User implements Serializable{



}
