package project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AppointmentManager {

    private Map<Integer, ArrayList<Appointment>> appointmentMap = new HashMap<>();
    private static AppointmentManager instance;

    public static AppointmentManager getInstance(){
        if(instance == null){
            instance = new AppointmentManager();
        }

        return instance;
    }

    public AppointmentManager(){}

    public Map<Integer, ArrayList<Appointment>> getAppointments(){return appointmentMap;}

    public void createAppointment(Appointment appointment, Client client) {
        int id = appointment.getIdAppointment();
        if(!appointmentMap.containsKey(id)){
            appointmentMap.put(id, new ArrayList<>());
        }
        appointmentMap.get(id).add(appointment);
        client.getAppointments().add(appointment);
    }
}


