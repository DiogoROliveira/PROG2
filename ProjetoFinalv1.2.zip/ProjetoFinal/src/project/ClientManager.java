package project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ClientManager {

    private Map<Integer, ArrayList<Client>> clientMap = new HashMap<>();
    private static ClientManager instance;

    public static ClientManager getInstance(){
        if(instance == null){
            instance = new ClientManager();
        }

        return instance;
    }

    public Map<Integer, ArrayList<Client>> getClients(){return clientMap;}

    public void addCliente(Client client){
        int NIF = client.getNIF();

        if(!clientMap.containsKey(NIF)) {
            clientMap.put(NIF, new ArrayList<>());
        }
        clientMap.get(NIF).add(client);

    }



}
