package GUI;

import javax.swing.*;
import javax.swing.border.LineBorder;
import project.*;
import java.awt.*;

public class LoginGUI extends JFrame {

    private final JButton btnLogin = new JButton("Login");
    private final JButton btnClear = new JButton("Clear");
    private JButton btnRegister;
    private final LoginControl loginC;

    public LoginGUI(JFrame frame) {

        loginC = new LoginControl();


        JLabel lbUsername = new JLabel("Username");
        lbUsername.setBounds(50, 100, 75 ,25);
        frame.add(lbUsername);


        JTextField tfUsername = new JTextField();
        tfUsername.setBorder(new LineBorder(Color.black, 1));
        tfUsername.setBounds(50, 125, 100, 25);
        frame.add(tfUsername);

        JLabel lbPassword = new JLabel("Password");
        lbPassword.setBounds(50, 150, 75, 25);
        frame.add(lbPassword);

        JPasswordField tfPassword = new JPasswordField();
        tfPassword.setBorder(new LineBorder(Color.black, 1));
        tfPassword.setBounds(50, 175, 100, 25);
        frame.add(tfPassword);


        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnClear);


        JPanel formPanel = new JPanel();
        formPanel.setOpaque(false);

        formPanel.add(tfUsername);

        formPanel.add(tfPassword);


        frame.setBackground(new Color(255, 128, 107));
        frame.pack();
        frame.add(buttonPanel);
        frame.setVisible(true);
        //BtnClear();
        //BtnLogin(frame);


    }

    /*public void clearTF() {
        tfUsername.setText("");
        tfPassword.setText("");
    }

    public void BtnClear() {
        btnClear.addActionListener(e -> clearTF());
    }

    public void BtnLogin(JFrame frame) {
        btnLogin.addActionListener(e -> actionBtnLogin(frame));
    }

    public void actionBtnLogin(JFrame frame) {
        String user, passwd;
        user = tfUsername.getText();
        passwd = Arrays.toString(tfPassword.getPassword());
        try {
            project.User login = loginC.Login(user, passwd);
            if (login instanceof project.Client) {
                jpUserLogin.setVisible(false);
            }
            if (login instanceof project.ServiceProvider) {
                jpUserLogin.setVisible(false);
            }
            if (login instanceof project.Employee) {
                jpUserLogin.setVisible(false);
            }
        } catch (project.UserNotFound e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }*/
}
